BBVA - Jazz: A lightweight analytical web server for data-driven applications - R client.
Copyright 2016-2017 Banco Bilbao Vizcaya Argentaria, S.A.

This product includes software developed at
BBVA (https://www.bbva.com/)
